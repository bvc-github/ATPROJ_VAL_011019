package TNG;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PROJ_PARA_TNG_BILL {
	WebDriver driver;
	@BeforeMethod
	public void beforemethod() {
		System.setProperty("webdriver.chrome.driver","C:\\software\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.get("http://demowebshop.tricentis.com/login");
		driver.findElement(By.id("Email")).sendKeys("sidwagh11@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("sidwagh");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

		driver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();
		List<WebElement> element=driver.findElements(By.id("termsofservice"));
		element.get(0).click();
		driver.findElement(By.name("checkout")).click();
		
		Select newaddress=new Select(driver.findElement(By.xpath("//*[@id=\"billing-address-select\"]")));
		newaddress.selectByVisibleText("New Address");
		}
	/*	
	}
  @Test
  @Parameters({"username","password"})
  public void ParamTest(String username,String password) throws Exception
  {
  	WebElement user=driver.findElement(By.name("username"));
  	user.sendKeys(username);
  	
  	driver.findElement(By.id("pwd")).sendKeys(password);
  	
  	//driver.findElement(By.xpath("//*[@id=\"loginform\"]/input[3]\n")).click();
  }
}
*/
	@Test(dataProvider="bill_address")
		public void dataProviderTest(String  Company,String Country,String City,String Address1,String Address2,String zipcode,String phone,String fax_no) throws InterruptedException
		{
	 	/*WebElement FN=driver.findElement(By.id("BillingNewAddress_FirstName"));
	 	FN.sendKeys(FirstName);
	 	System.out.println("1");
	    Thread.sleep(1000);
	    
	 	WebElement LN=driver.findElement(By.id("BillingNewAddress_LastName"));
	 	LN.sendKeys(LastName);
	 	System.out.println("2");
	    Thread.sleep(1000);
	    
	 	WebElement email=driver.findElement(By.id("BillingNewAddress_Email"));
	 	email.sendKeys(Email);
	 	System.out.println("3");
	    Thread.sleep(1000);
	    */
	 	WebElement comp=driver.findElement(By.id("BillingNewAddress_Company"));
	  	comp.sendKeys(Company);
	    Thread.sleep(1000);
	    
	    
		Select sCountry=new Select(driver.findElement(By.id("BillingNewAddress_CountryId")));
		sCountry.selectByVisibleText(Country);
	    
		Select sState=new Select(driver.findElement(By.id("BillingNewAddress_StateProvinceId")));
		sState.selectByIndex(0);
		
	 	WebElement bnaCity=driver.findElement(By.id("BillingNewAddress_City"));
	  	bnaCity.sendKeys(City);
	  	
	  	
	  	String check1="^[\\p{L} .'-]+$";
	    if(Pattern.matches(check1,City))
        {
            System.out.println("City is valid");
        }
        else
        {
            System.out.println("City is invalid");
            System.out.println("Browser closed");
            driver.close();
        }
	   
        Assert.assertTrue((Pattern.matches(check1,City)),"IT IS BLANK ,NOT FILLED");
     
	  	
	  	
	  	
	  	
	  	
		
	  	WebElement add_1=driver.findElement(By.id("BillingNewAddress_Address1"));
	  	add_1.sendKeys(Address1);
	  	
	  	String check2="^[\\p{L} .'-]+$";
	    if(Pattern.matches(check2,Address1))
        {
            System.out.println("Address1 is valid");
        }
        else
        {
            System.out.println("Address1 is invalid");
            System.out.println("Browser closed");
            driver.close();
        } 
	   
        Assert.assertTrue((Pattern.matches(check2,Address1)),"IT IS BLANK ,NOT FILLED");
	  	
	  	WebElement add_2=driver.findElement(By.id("BillingNewAddress_Address2"));
	  	add_2.sendKeys(Address2);
	  	
		WebElement zcode=driver.findElement(By.id("BillingNewAddress_ZipPostalCode"));
	  	zcode.sendKeys(zipcode);
	  	
	  	
	  	String check3="\\d{0,10}";
	    if(Pattern.matches(check3,zipcode))
        {
            System.out.println("zipcode is valid");
        }
        else
        {
            System.out.println("zipcode is invalid");
            System.out.println("Browser closed"); 
            driver.close();
        }
	   
        Assert.assertTrue((Pattern.matches(check3,zipcode)),"IT IS BLANK ,NOT FILLED");
	  	
	  	WebElement phoneno=driver.findElement(By.id("BillingNewAddress_PhoneNumber"));
	  	phoneno.sendKeys(phone);
	  	String check4="\\d{0,10}";
	    if(Pattern.matches(check4,phone))
        {
            System.out.println("phone is valid");
        }
        else
        {
            System.out.println("phone is invalid");
            System.out.println("Browser closed");
            driver.close();
        }
	   
        Assert.assertTrue((Pattern.matches(check4,phone)),"IT IS BLANK ,NOT FILLED");
	  	
	  	
	  	
	  	WebElement faxno=driver.findElement(By.id("BillingNewAddress_FaxNumber"));
	  	faxno.sendKeys(fax_no);
	  	
	  	driver.findElement(By.xpath("//*[@id=\"billing-buttons-container\"]/input")).click();
	  	
	  	Thread.sleep(10000);
	  	driver.close();
		}
	@DataProvider(name="bill_address")
	public Object[][] dataFromXml()
	{
		return new Object[][] {
		new Object[] {"Company1","India","MUMBAI","address","address2","849387","3479234729","3537252-46442"},
		new Object[] {"Company2","India","","address1","address","849273","9086549754","3saaf252-46442"},
		new Object[] {"Company3","Austria","CHENNAI","plot","Plot","849273","3479234729",""},
		new Object[] {"Company4","Canada","BANGALORE","addr","address2","440067","9988776655","3537252-46442"},
		new Object[] {"Company4","India","INDORE","addres","address2","849273","","3537252-46442"},
		new Object[] {"Company4","India","Delhi","address123","address2","849273","9845776835","3537252-46442"},
	};
	}
}
	